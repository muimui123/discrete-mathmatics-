import java.util.Scanner;
import java.util.*;
public class main {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		stacks stack = new stacks();
		String input = scanner.nextLine();
		while(!input.equals("***")){
			if (input.contains("PUSH")){
				String element = input.split(" ")[1];
				stack.push(element);
			}else if (input.equals("POP")){
				stack.pop();
			} else if (input.equals("PRINT")){
				stack.print();
			} else if (input.equals("CLEAR")){
				stack.clear();
			}
		input = scanner.nextLine();
		}
	}
		
}	