
public class LLNode206<T> {

	T data;
	LLNode206<T> next;	//link to next node
	
	public LLNode206(T d) {
		data = d;
		next = null;
	}
}
