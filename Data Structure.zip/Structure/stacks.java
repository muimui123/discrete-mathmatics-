
public class stacks {
	
	LinkedList206<String> stack;
	
	public stacks(){
		stack = new LinkedList206<String> ();
	}
	
	public void push (String n){
		stack.addNodeToEnd(n);
	}
	
	public void pop(){
		if(stack.getLength() > 0){
			String item = stack.removeAt(stack.getLength()-1);
			System.out.println(item);
		} else{
			System.out.println("empty");
		}
	}
	
	public void clear(){
		while(stack.getLength() > 0){
			stack.removeAt(0);
		}
	}
	
	public void print(){
		stack.printAll();
		
	}
}
