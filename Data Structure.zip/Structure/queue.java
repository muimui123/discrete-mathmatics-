public class queue {
	
	LinkedList206<String> queue;
	
	public queue(){
		queue = new LinkedList206<String>();
	}
	
	public void enqueue (String n){
		queue.addNodeToEnd(n);
	}
	
	public void dequeue(){
		if(queue.getLength() > 0){
			String item = queue.removeAt(0);
			System.out.println(item);
		} else{
			System.out.println("empty");
		}
	}
	
	public void clear(){
		while(queue.getLength() > 0){
			queue.removeAt(0);
		}
	}
	
	public void print(){
		queue.printAll();
		
	}
}