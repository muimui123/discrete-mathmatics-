import java.util.Scanner;
import java.util.*;
public class main2 {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		queue queue = new queue();
		String input = scanner.nextLine();
		while(!input.equals("***")){
			if (input.contains("ENQUEUE")){
				String el = input.split(" ")[1];
				queue.enqueue(el);
			}else if (input.equals("DEQUEUE")){
				queue.dequeue();
			} else if (input.equals("PRINT")){
				queue.print();
			} else if (input.equals("CLEAR")){
				queue.clear();
			}
		input = scanner.nextLine();
		}
	}
		
}	