import java.util.ArrayList;
import java.util.Scanner;
import java.util.*;

public class Main {
	
	private static Node[] nodes;
	private static ArrayList<Node> history = new ArrayList<Node>();
	private static int current_index = 0;
	
	
	//read in files
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		String[] inputs = s.nextLine().split(" ");
		String begin = s.nextLine();
		
		ArrayList<String> groups = new ArrayList<String>();
		String row = s.nextLine();
		while(!row.equals("***")){
			groups.add(row);
			row = s.nextLine();
		}
		
		nodes = new Node [inputs.length];
		int counter = 0;
		for(String input:inputs){
			nodes[counter++] = new Node (input);
		}
		
		for(String group:groups){
			String[] elements = group.split(" ");
			Node from = getNode(elements[0]);
			Node to = getNode(elements[1]);
			addNeighbors(from,to);
		}
		
		System.out.println("Node Neighbors:");
		for (Node node: nodes){
			node.printAll();
		}
		
		//depth
		Node start_node = getNode(begin);
		String result = depthSearch(start_node);
		System.out.println("Depth-First Search:");
		System.out.println(result);
		
		//breathe
		history.clear();
		for(Node node: nodes){
			node.visited = false;
		}
		start_node = getNode(begin);
		start_node.visited = true;
		history.add(start_node);
		result = start_node.toString() + " ";
		System.out.println("Breath-First Search:");
		result = breathSearch(start_node, result);
		System.out.println(result);
	}	
		
		private static void addNeighbors (Node from, Node to){
			from.addNeighbor(to);
			to.addNeighbor(from);
		}
		
		private static Node getNode(String input){
			for(Node node: nodes){
				if(node.isNode(input)){
					return node;
				}
			}
			return null;
		
		}
		//depth
		private static String depthSearch(Node node){
			node.visited = true;
			history.add(node);
			String result = node.toString() + " ";
			Node next_Node = node.getNextNeighbor();
			if(next_Node == null){
				int index_look  = history.size()-2;
				Node parent_node = history.get(index_look);
				next_Node = parent_node.getNextNeighbor();
				while(next_Node == null){
					index_look --;
					if(index_look < 0) {
						return result;
					}
					parent_node = history.get(index_look);
					next_Node = parent_node.getNextNeighbor();
				}
			}
			result += depthSearch(next_Node);
			return result;
		}
		//breath
		private static String breathSearch(Node node, String result){
			Node next_Node = node.getNextNeighbor();
			while(next_Node != null){
				history.add(next_Node);
				result += next_Node + " ";
				next_Node = node.getNextNeighbor();
			}
				if(history.size() >= nodes.length){
					return result;
				}
			next_Node = history.get(++current_index);
			result = breathSearch(next_Node, result);
			return result;
		}
}