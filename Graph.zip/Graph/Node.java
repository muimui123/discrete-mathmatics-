import java.util.ArrayList;
import java.util.Collections;

public class Node implements Comparable<Node> {
	String name;
	boolean visited;
	ArrayList<Node> neighbors;
	
	public Node(String d) {
		name = d;
		visited = false;
		neighbors = new ArrayList<>();
	}

	@Override
	public int compareTo(Node o) {
		return name.compareTo(o.name);
	}
	
	//adding neighbors
	public void addNeighbor (Node neighbor){
		neighbors.add(neighbor);
		Collections.sort(neighbors);
	}
	
	//check points
	public boolean isNode(String input){
		return name.equals(input);
	}
	
	public String toString(){
		return name;
	}
	
	public void printAll(){
		String result = new String();
		for (Node n: neighbors){
			result += n.toString()+" ";
		}
		System.out.println(name + ": " + result);
	}
	
	//get all the points
	public Node getNextNeighbor (){
		for(Node node: neighbors){
			if(!node.visited){
				node.visited = true;
				return node;
			}
		}
		return null;
	}
}