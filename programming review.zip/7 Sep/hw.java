import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class hw {

	//for the beginning
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		ArrayList<Double> numbers = new ArrayList<Double>();
		int n = s.nextInt();

		//sum
		double sum = 0;
		for (int i=0; i<n; i++) {
			double num = s.nextDouble();
			sum += num;
			numbers.add(num);
		}
		System.out.printf( "Sum: %.2f" , sum );
		s.close();

		//Avg
		double avg = sum/n;
		System.out.printf(" Avg: %.2f " , avg);

		//Median
		Collections.sort(numbers);
		double median = 0;

		//odd, can pick the center
		if (n % 2 == 1) {
			median = numbers.get(n/2);
			System.out.printf(" Median: %.2f " , median);
		}

		//even, a+b/2
		if (n % 2 == 0) {
			double a = numbers.get(n/2-1);
			double b = numbers.get(n/2);
			median = (a+b)/2;
			System.out.printf(" Median: %.2f" , median);
		}

		//Mode
		int [] freq = new int [n];
		int max = 2;
		ArrayList<Double> mode = new ArrayList<Double>();
		Arrays.fill(freq, 1);
		for (int i = 1; i < n ; i++) {
			if (numbers.get(i).doubleValue() == numbers.get(i-1).doubleValue()) {
				freq[i] += freq[i-1];
			}
			else {
				if(freq[i-1] > max) {
					max = freq[i-1];
					mode = new ArrayList<Double>();
					mode.add(numbers.get(i-1));
				}
				else if (freq [i-1] == max) {
					mode.add(numbers.get(i-1));
				}
			}
		}
 		

		String sss = "";
		for(double i: mode) {
			sss += i + " ";
		}
		if(sss.equals("")) {
			System.out.println(" Mode: no mode");
		}
		else {
			System.out.println(" Mode: " + sss);
		}

	}

}
